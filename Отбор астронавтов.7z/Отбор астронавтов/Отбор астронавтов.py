from flask import Flask
from flask import url_for

app = Flask(__name__)


@app.route('/astronaut_selection')
def image_mars():
    return f"""<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                    <title>Отбор астронавтов</title>
                  </head>
                  <body>
                    <h1>Анкета претендента</h1>
                    <h2>на участие в миссии</h2>
                  </body>
                  <body>
                    <form>
                      <input type="text" placeholder="Введите фамилию"><br>
                      <input type="text" placeholder="Введите имя"><br>
                      <input type="text" placeholder="Введите адрес почты">
                      <p>Какое у Вас образование?<p>
                      <select name="user_profile_color_1">
                        <option value="1">Начальное</option>
                        <option value="2">Общее</option>
                        <option value="3">Среднее</option>
                        <option value="4">Высшее</option>
                      </select>
                      <p>Какие у Вас есть профессии?<p>
                      <label>
                        <input type="checkbox">
                        инженер-исследователь
                      </label><br>
                      <label>
                        <input type="checkbox">
                        пилот
                      </label><br>
                      <label>
                        <input type="checkbox">
                        строитель
                      </label><br>
                      <label>
                        <input type="checkbox">
                         экзобиолог
                      </label><br>
                      <label>
                        <input type="checkbox">
                        врач
                      </label><br>
                      <label>
                        <input type="checkbox">
                        инженер по терраформированию
                      </label><br>
                      <label>
                        <input type="checkbox">
                        климатолог
                      </label><br>
                      <label>
                        <input type="checkbox">
                        специалист по радиационной защите
                      </label><br>
                      <label>
                        <input type="checkbox">
                         инженер жизнеобеспечения
                      </label>
                      <p>Укажите пол</p>
                        <label>
                          <input type="radio"">
                          Мужской
                        </label><br>
                        <label>
                          <input type="radio" checked>
                          Женский
                        </label>
                      <p>Почему Вы хотите принять участие в миссии?<p>
                        <textarea>
                        </textarea>
                      <p>Приложите фотографию<p>
                      <p class="n1"><input type="submit" value="Выберите файл">Файл не выбран</p>
                      <label>
                          <input type="radio">
                          Готовы остаться на Марсе?
                      </label><br>
                      <input type="submit" value="Выбрать">
                    </form>
                  </body>
                </html>"""


if __name__ == '__main__':
    from waitress import serve
    serve(app, port=8080, host='127.0.0.1')
